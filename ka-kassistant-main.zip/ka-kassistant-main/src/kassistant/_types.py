"""Internal types."""

from typing import Literal

type LABEL_SIZE = Literal[
    "STOCK_4X6",
    "STOCK_4X675_LEADING_DOC_TAB",
    "STOCK_4X675_TRAILING_DOC_TAB",
]
