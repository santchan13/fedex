"""K-ERP integration assistant."""

import logging

logging.basicConfig(level=logging.DEBUG)

__version__ = "0.8.10"
